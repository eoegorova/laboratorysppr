from django.shortcuts import render
from django.http import HttpResponse
from .models import Unit
from .forms import UnitForm

import os
import random
from surprise import dump
import pandas as pd


def recommend(user_id):
    # Загрузка данных и модели
    df_ratings = pd.read_csv('media/cellphones_ratings.csv', on_bad_lines='skip')
    df_cellphones = pd.read_csv('media/cellphones_data.csv')
    loaded_algo = dump.load(os.path.expanduser('media/svd_model'))[1]

    # Создание отображения идентификаторов телефонов в их названия
    mapping = dict(zip(df_cellphones['cellphone_id'], df_cellphones['model']))

    # Создание антитестсета с учетом оцененных телефонов
    user_rated_items = df_ratings[df_ratings['user_id'] == int(user_id)]['cellphone_id'].tolist()
    anti_testset = [[user_id, cellphone_id, 0.] for cellphone_id in df_cellphones['cellphone_id'] if cellphone_id not in user_rated_items]
    
    # Получение предсказаний для неоцененных телефонов
    predictions = loaded_algo.test(anti_testset)

    # Выбор уникальных рекомендаций с добавлением случайности
    recommendations_list = []
    while len(recommendations_list) < 5:
        random_prediction = random.choice(predictions)
        if random_prediction[1] not in [rec[1] for rec in recommendations_list]:
            recommendations_list.append(random_prediction)

    recommendations = []
    for uid, iid, true_r, est, _ in recommendations_list:
        cellphone_name = mapping.get(iid, "Неизвестный телефон")
        recommendations.append((cellphone_name, round(est, 3)))

    return recommendations


def display_random_users():
    # Загрузка данных
    df_ratings = pd.read_csv('media/cellphones_ratings.csv', on_bad_lines='skip')
    num_users = 10
    df_cellphones = pd.read_csv('media/cellphones_data.csv')
    # Создание отображения идентификаторов телефонов в их названия
    mapping = dict(zip(df_cellphones['cellphone_id'], df_cellphones['model']))
    
    # Получение случайных пользователей и их оцененных телефонов
    unique_users = df_ratings['user_id'].unique()
    sampled_users = random.sample(list(unique_users), num_users)
    
    random_users_ratings = []
    for user in sampled_users:
        user_ratings = df_ratings[df_ratings['user_id'] == user]
        user_ratings_info = []
        for _, row in user_ratings.iterrows():
            cellphone_name = mapping.get(row['cellphone_id'], "Неизвестный телефон")
            user_ratings_info.append((cellphone_name, row['rating']))
        random_users_ratings.append((user, user_ratings_info))
    
    return random_users_ratings

def index(request):
	return render(request, 'system/index.html')
	

def recom(request):
	work = Unit.objects.order_by('-user_id')
	if work:
		for n in work:
			if n.recomendations=="NULL":
				n.recomendations = recommend(n.user_id)
				n.save()
	return render(request, 'system/recom.html', {'work':work})
	

def post(request):
	ex = display_random_users()
	error = ''
	if request.method == 'POST':
		form = UnitForm(request.POST)

		if form.is_valid():
			form.save()
		else:
			error = 'Ошибка заполнения'
			
	form = UnitForm()
	data = {
		'form': form,
		'error': error,
		'ex': ex
	}
	return render(request, 'system/post.html', data)
